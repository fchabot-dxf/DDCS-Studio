// Utilities for mapping wizard params to middleViz SVG IDs

export function getVizIds({ featureType = 'pocket', axis = 'X', dir1 = 'pos', twoAxis = false } = {}) {
  // canonical IDs based on SVG naming conventions used in src/assets/middleViz.svg
  const root = `middle_probe_${featureType}`;
  const axisGroupId = `${root}_${axis}_${dir1}`; // e.g. middle_probe_pocket_X_pos

  // prefer XY probe visual for the top-down view (many probe visuals exist both in XY and XZ/YZ blocks)
  const probePathId = `${axisGroupId}_1axis_XY_probepath1`;
  const probePath2Id = `${axisGroupId}_1axis_XY_probepath2`;

  // retract path ids vary between "retractpathpos/retractpathneg" and "retractarrow..." - return candidates
  const retractCandidates = [
    `${axisGroupId}_1axis_XY_retractpath${dir1 === 'pos' ? 'pos' : 'neg'}`,
    `${axisGroupId}_1axis_XY_retractarrow${dir1 === 'pos' ? 'pos' : 'neg'}`
  ];

  // two-axis / jog path: belongs to the *opposite* axis group (e.g. X->Y uses Y_pos_2axis_YtoX_pos)
  const oppositeAxis = axis === 'X' ? 'Y' : 'X';
  const oppositeAxisGroup = `middle_probe_${featureType}_${oppositeAxis}_${dir1}`;
  const twoAxisParent = `${oppositeAxisGroup}_2axis`;
  const axisDirKey = `${oppositeAxis}to${axis}`; // e.g. YtoX when secondAxis is X
  const jogPathId = `${oppositeAxisGroup}_2axis_${axisDirKey}_${dir1}_jogpath`;
  const twoAxisChildId = `${oppositeAxisGroup}_2axis_${axisDirKey}_${dir1}`;

  return {
    rootId: `#${root}`,
    axisGroupId: `#${axisGroupId}`,
    probePathId: `#${probePathId}`,
    probePath2Id: `#${probePath2Id}`,
    retractCandidates: retractCandidates.map(id => `#${id}`),
    twoAxisParentId: `#${twoAxisParent}`,
    twoAxisChildId: `#${twoAxisChildId}`,
    jogPathId: `#${jogPathId}`,
    twoAxis: !!twoAxis
  };
}

// Resolve the first existing selector from the candidates and return element selectors that exist in DOM
export function resolveVizIds(params) {
  const ids = getVizIds(params);
  const doc = typeof document !== 'undefined' ? document : null;
  const resolved = { ...ids };

  if (doc) {
    // probePath (prefer probepath1, fallback to probepath2)
    const p1 = doc.querySelector(ids.probePathId);
    const p2 = doc.querySelector(ids.probePath2Id);
    resolved.probePathSelector = p1 ? ids.probePathId : (p2 ? ids.probePath2Id : null);

    // retract: find first candidate that exists
    const foundRetract = ids.retractCandidates.map(s => doc.querySelector(s)).find(Boolean);
    resolved.retractPathSelector = foundRetract ? `#${foundRetract.id}` : null;

    // two-axis jog / child
    const twoParent = doc.querySelector(ids.twoAxisParentId);
    const twoChild = doc.querySelector(ids.twoAxisChildId);
    resolved.twoAxisParentExists = !!twoParent;
    resolved.twoAxisChildExists = !!twoChild;
    resolved.jogPathSelector = doc.querySelector(ids.jogPathId) ? ids.jogPathId : null;
  } else {
    resolved.probePathSelector = null;
    resolved.retractPathSelector = null;
    resolved.jogPathSelector = null;
    resolved.twoAxisParentExists = false;
    resolved.twoAxisChildExists = false;
  }

  console.debug('resolveVizIds ->', { params, resolved });
  return resolved;
}

// Expose helpers to the global window for Playwright/E2E access
if (typeof window !== 'undefined') {
  window.getVizIds = getVizIds;
  window.resolveVizIds = resolveVizIds;
}
