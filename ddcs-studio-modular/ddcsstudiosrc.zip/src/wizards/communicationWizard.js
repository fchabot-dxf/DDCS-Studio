/**
 * DDCS Studio - Communication Wizard
 * Generates G-code for controller communication and UI interactions
 */

// CommunicationWizard: Generates UI G-code (popup/status/input/etc.)
// No runtime verifier is invoked here to keep generation deterministic.
export class CommunicationWizard {
    constructor() {
        // No special initialization needed
    }

    generate(params) {
        const {
            type,       // popup, status, input, beep, alarm, dwell, keywait
            msg,        // Message text
            val,        // Value (for beep/dwell)
            popupMode,  // Popup mode (for popup type)
            id,         // Variable ID (for input type)
            dest,       // Destination variable (for input type)
            slot1,      // Data slot 1 (#1510)
            slot2,      // Data slot 2 (#1511)
            slot3,      // Data slot 3 (#1512)
            slot4       // Data slot 4 (#1513)
        } = params;

        let gcode = '';

        // Generate slots code if supported
        const supportsSlots = ['popup', 'status', 'alarm', 'input'].includes(type);
        const slotsCode = this.generateSlotsCode(supportsSlots, slot1, slot2, slot3, slot4);

        // Generate specific communication type
        switch (type) {
            case 'popup':
                gcode = this.generatePopup(slotsCode, popupMode, msg);
                break;
            case 'status':
                gcode = this.generateStatus(slotsCode, msg);
                break;
            case 'input':
                gcode = this.generateInput(slotsCode, id, dest, msg);
                break;
            case 'beep':
                gcode = this.generateBeep(val);
                break;
            case 'alarm':
                gcode = this.generateAlarm(slotsCode, msg);
                break;
            case 'dwell':
                gcode = this.generateDwell(val);
                break;
            case 'keywait':
                gcode = this.generateKeyWait();
                break;
            default:
                gcode = `( Unknown communication type: ${type} )`;
        }

        // Ensure #2070 usage is safe: restrict target id to #50-#499.
        // If caller supplied an unsafe id, use a safe temp (e.g. #100) and copy to destination.
        return gcode;
    }

    generateSlotsCode(supportsSlots, slot1, slot2, slot3, slot4) {
        if (!supportsSlots) return '';

        let slotsCode = '';
        // V9.20: Data Slots Integration (No spaces around =)
        if (slot1) slotsCode += `#1510=${slot1}\n`;
        if (slot2) slotsCode += `#1511=${slot2}\n`;
        if (slot3) slotsCode += `#1512=${slot3}\n`;
        if (slot4) slotsCode += `#1513=${slot4}\n`;

        return slotsCode;
    }

    generatePopup(slotsCode, mode, msg) {
        let gcode = `${slotsCode}( Popup Message )\n`;
        gcode += `#1505=${mode}\n`;
        gcode += `(MSG,${msg})`;
        return gcode;
    }

    generateStatus(slotsCode, msg) {
        let gcode = `${slotsCode}( Status Bar Update )\n`;
        gcode += `#1503=1\n`;
        gcode += `(MSG,${msg})`;
        return gcode;
    }

    generateInput(slotsCode, id, dest, msg) {
        // V9.20: DDCS Compliant - #2070 can only write to #50-#499
        // Normalize id (allow '#100' or 100 input) and enforce safe range.
        const idNum = Number(String(id).replace('#', ''));
        let gcode = `${slotsCode}( Numeric Input - DDCS Safe )\n`;
        if (Number.isFinite(idNum) && idNum >= 50 && idNum <= 499) {
            // Safe to use directly
            gcode += `#2070=${idNum}(${msg})\n`;
            gcode += `${dest}=#${idNum} (Copy to persistent)`;
        } else {
            // Use a safe temporary variable (#100) and copy result to destination
            const temp = 100;
            gcode += `#2070=${temp}(${msg})\n`;
            gcode += `${dest}=#${temp} (Copy to persistent)`;
        }
        return gcode;
    }

    generateBeep(val) {
        return `( System Beep )\n#2042=${val}`;
    }

    generateAlarm(slotsCode, msg) {
        let gcode = `${slotsCode}( Trigger Alarm )\n`;
        gcode += `#3000=1(MSG,${msg})`;
        return gcode;
    }

    generateDwell(val) {
        return `G4 P${val}`;
    }

    generateKeyWait() {
        let gcode = `( Key Wait )\n`;
        gcode += `#2038=0\n`;
        gcode += `M0`;
        return gcode;
    }

    /**
     * Get UI field visibility based on communication type
     * This helps the UI know which fields to show/hide
     */
    getFieldVisibility(type) {
        return {
            showMode: type === 'popup',
            showValue: type === 'beep' || type === 'dwell',
            showMessage: type !== 'dwell' && type !== 'keywait',
            showSlots: ['popup', 'status', 'alarm', 'input'].includes(type),
            showVar: type === 'input'
        };
    }
}
