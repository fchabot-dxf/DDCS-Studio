/**
 * DDCS Studio - Middle Wizard
 * Generates G-code for finding center of pockets or bosses
 */

export class MiddleWizard {
    constructor() {
        // No special initialization needed
    }

    generate(params) {
        const {
            featureType,    // 'pocket' or 'boss'
            axis,           // 'X' or 'Y' (primary axis)
            dir1,           // 'pos' or 'neg' (first probe direction)
            dir2,           // optional 'pos' or 'neg' (secondary direction for the same axis)
            twoAxis,        // optional boolean -> perform X then Y (or Y then X) full center-find
            syncA,          // Sync A axis with Y
            slave,          // Slave select value (3=A,4=B)
            wcs,            // WCS target
            dist,           // Max probe distance
            retract,        // Retract distance
            safeZ,          // Safe Z height
            clearance,      // Clearance distance (used for findBoth auto-jog)
            f_fast,         // Fast feed rate
            f_slow,         // Slow feed rate
            port,           // Probe input port
            level,          // Probe level (0 or 1)
            qStop,          // Stop mode (0 or 1)
            findBoth        // If true, automatically perform both edge probes without user pauses
        } = params;

        // Primary axis-specific probe status/result and offset for WCS write
        const axisStatus = axis === 'X' ? '#1920' : '#1921';
        const axisResult = axis === 'X' ? '#1925' : '#1926';
        const axisOffset = axis === 'X' ? 0 : 1;

        // Direction signs — dir2 may be explicitly provided (when Find Both + secondary direction control used)
        const dir1Sign = dir1 === 'pos' ? '+' : '-';
        const resolvedDir2 = typeof dir2 === 'string' ? dir2 : (dir1 === 'pos' ? 'neg' : 'pos');
        const dir2Sign = resolvedDir2 === 'pos' ? '+' : '-';

        // If twoAxis mode requested, determine secondary axis (the 'other' axis)
        // Treat `findBoth` as a request for 2-axis sequence as well (UI uses same checkbox)
        const doTwoAxis = !!twoAxis || !!findBoth;
        const secondAxis = doTwoAxis ? (axis === 'X' ? 'Y' : 'X') : null;

        // Generate WCS code and header label (include 2-axis hint when active)
        const { wcsCode, wcsLabel } = this.generateWCSCode(wcs);
        const typeLabel = featureType === 'pocket' ? 'Pocket (Inside)' : 'Boss (Outside)';

        // Build G-code (header + variables)
        let gcode = this.generateHeader(axis, typeLabel, wcsLabel, dir1Sign, dir2Sign, dist, retract, f_fast, f_slow, findBoth);
        if (doTwoAxis) gcode += `( 2-Axis mode: ${axis} then ${secondAxis} )\n`;

        gcode += this.generateMotionVariables(dist, retract, f_fast, f_slow, port, clearance);
        gcode += this.generatePrecalcMotionVariables(dist, retract, safeZ, clearance, 0, 0);
        gcode += wcsCode;
        gcode += this.generateConfirmStart();
        gcode += `G91  ( Incremental mode )\n\n`;

        // --- Primary axis sequence (always run) ---
        if (featureType === 'pocket') {
            gcode += this.generatePocketSequence(axis, dir1Sign, dir2Sign, axisStatus, axisResult, level, qStop, retract, findBoth, 51);
        } else {
            gcode += this.generateBossSequence(axis, dir1Sign, dir2Sign, axisStatus, axisResult, level, qStop, retract, findBoth, 51);
        }

        // Calculate & store first-axis center (#53) before any transition to second axis
        gcode += this.generateCenterCalculation(51, 52, 53);

        // If 2-axis mode requested, do a safe transition then run the second-axis probing (store into #54/#55 and center in #56)
        if (doTwoAxis) {
            // Save current Z (machine coord) and require user reposition before secondary axis.
            // This satisfies the "Pause between axes" + Z persistence requirements.
            gcode += `#55=#882  ( Save current Z machine position before axis change )\n`;
            gcode += `G0 Z#17  ( Safe Z before secondary axis )\n\n`;
            gcode += `#1505=1  ( Press Enter to reposition for secondary axis )\n\n`;
            gcode += `G53 G0 Z#55  ( Restore saved Z before secondary axis )\n\n`;

            // compute axis-specific status/result for second axis
            const secAxisStatus = secondAxis === 'X' ? '#1920' : '#1921';
            const secAxisResult = secondAxis === 'X' ? '#1925' : '#1926';

            // second-axis probe directions come from the secondary-direction control (dir2)
            const secDir1Sign = dir2 === 'pos' ? '+' : '-';
            const secDir2Sign = dir2 === 'pos' ? '-' : '+';

            // Insert a comment that matches the visualiser '2axis' naming convention (e.g. XtoY)
            const axisDirKey = axis === 'X' ? 'XtoY' : 'YtoX';
            gcode += `( 2axis_${axisDirKey}_${dir2} )\n\n`;

            if (featureType === 'pocket') {
                gcode += this.generatePocketSequence(secondAxis, secDir1Sign, secDir2Sign, secAxisStatus, secAxisResult, level, qStop, retract, findBoth, 54);
            } else {
                gcode += this.generateBossSequence(secondAxis, secDir1Sign, secDir2Sign, secAxisStatus, secAxisResult, level, qStop, retract, findBoth, 54);
            }

            // compute second-axis center into #56
            gcode += this.generateCenterCalculation(54, 55, 56);

            // Final retract (after second axis)
            gcode += this.generateFinalRetract(secondAxis, secDir2Sign);

            // Write both axes to WCS (X -> #53, Y -> #56) — maintain order: X then Y
            gcode += this.generateWCSWrite(wcsLabel, 'X', 0, '#53');
            gcode += this.generateWCSWrite(wcsLabel, 'Y', 1, '#56');
        } else {
            // Single-axis finalisation (existing behaviour)
            gcode += this.generateFinalRetract(axis, dir2Sign);
            gcode += this.generateWCSWrite(wcsLabel, axis, axisOffset, '#53');
        }

        // Dual gantry sync (only relevant when Y axis is part of the operation)
        if (syncA && (axis === 'Y' || twoAxis)) {
            const s = slave || '3';
            gcode += `( Dual Gantry Sync )\n`;
            gcode += `#[#70+${s}]=#883  ( Write A machine pos to WCS slave offset )\n\n`;
        }

        gcode += this.generateFooter();
        return gcode;
    }

    generateWCSCode(wcs) {
        let wcsCode = '';
        let wcsLabel = '';

        if (wcs === 'active') {
            wcsCode = `( Read Active WCS )\n#71=1 ( Wash: prime )\n#71=#578 ( Read active WCS: 1=G54, 2=G55, etc )\n`;
            wcsCode += `#70=805+[#71-1]*5  ( Calculate base address )\n\n`;
            wcsLabel = 'Active WCS';
        } else {
            const wcsMap = {
                'G54': 805, 'G55': 810, 'G56': 815,
                'G57': 820, 'G58': 825, 'G59': 830
            };
            const baseAddr = wcsMap[wcs];
            wcsCode = `( Target: ${wcs} )\n#70=${baseAddr}  ( Base address )\n\n`;
            wcsLabel = wcs;
        }

        return { wcsCode, wcsLabel };
    }

    generateHeader(axis, typeLabel, wcsLabel, dir1Sign, dir2Sign, dist, retract, f_fast, f_slow, findBoth) {
        let header = `( Middle Finder | ${axis} Axis | ${typeLabel} | ${wcsLabel} )\n`;
        header += `( DDCS M350 V10.0 Compliant )\n`;  
        header += `( First probe: ${dir1Sign}${axis}, then ${dir2Sign}${axis} )\n`;
        header += `( Distance: ${dist}mm | Retract: ${retract}mm | Fast: ${f_fast} | Slow: ${f_slow} )\n`;
        header += `( Find both edges: ${findBoth ? 'Yes' : 'No'} )\n\n`;
        return header;
    }

    generateMotionVariables(dist, retract, f_fast, f_slow, port, clearance) {
        let vars = `( Motion Variables - #1-#10 for seamless movement )\n`;
        vars += `#1=${dist}      ( Max probe distance )\n`;
        vars += `#2=${retract}   ( Retract distance )\n`;
        vars += `#3=${f_fast}    ( Fast feed )\n`;
        vars += `#4=${f_slow}    ( Slow feed )\n`;
        vars += `#5=${port}      ( Probe port )\n`;
        vars += `#6=${clearance} ( Clearance/jog distance )\n`;
        vars += `( Result storage - #50+ for persistence )\n`;
        vars += `#51=0            ( First axis - first edge result )\n`;
        vars += `#52=0            ( First axis - second edge result )\n`;
        vars += `#53=0            ( First axis - center result )\n`;
        vars += `#54=0            ( Second axis - first edge result )\n`;
        vars += `#55=0            ( Second axis - second edge result )\n`;
        vars += `#56=0            ( Second axis - center result )\n\n`;
        return vars;
    }

    generatePrecalcMotionVariables(dist, retract, safeZ, clearance, travelDist, scanDepth) {
        // dist -> #1, retract -> #2, clearance -> #6, safeZ -> #17
        const td = parseInt(travelDist) || 0;
        const sz = parseInt(safeZ) || 0;
        let vars = `( Pre-calculated motion values - #7-#19 )\n`;
        vars += `#7=[0-#1] ( Negative max probe )\n`;
        vars += `#8=#1     ( Positive max probe )\n`;
        vars += `#9=[0-#2] ( Negative retract )\n`;
        vars += `#10=#2    ( Positive retract )\n`;
        vars += `#11=[0-#2*2] ( Negative double retract )\n`;
        vars += `#12=[#2*2]   ( Positive double retract )\n`;
        vars += `#13=#6      ( Positive clearance )\n`;
        vars += `#14=[0-#6]  ( Negative clearance )\n`;
        vars += `#15=${td} ( Positive travel )\n`;
        vars += `#16=[0-${td}] ( Negative travel )\n\n`;
        vars += `#17=${sz} ( Safe Z )\n`;
        return vars;
    }

    generateConfirmStart() {
        return `( Confirm Start )\n#1505=1 (Press Enter to probe)\n\n`;
    }

    generatePocketSequence(axis, dir1Sign, dir2Sign, axisStatus, axisResult, level, qStop, retract, findBoth, resultBase = 51) {
        let code = `( === POCKET: Probe from inside toward walls === )\n\n`;

        // numeric result slots (dynamic so same routine can be used for axis1 or axis2)
        const firstEdgeVar = `#${resultBase}`;           // e.g. #51 or #54
        const secondEdgeVar = `#${resultBase + 1}`;      // e.g. #52 or #55
        const centerVar = `#${resultBase + 2}`;          // e.g. #53 or #56

        // Prepare signed variable names
        const firstProbeVar = (dir1Sign === '+') ? '#8' : '#7';
        const firstRetractInv = (dir1Sign === '+') ? '#9' : '#10';
        const firstSlowVar = (dir1Sign === '+') ? '#12' : '#11';
        const oppProbeVar = (dir2Sign === '+') ? '#8' : '#7';
        const oppRetractInv = (dir2Sign === '+') ? '#9' : '#10';
        const oppSlowVar = (dir2Sign === '+') ? '#12' : '#11';
        const travelProbeVar = (dir2Sign === '+') ? '#8' : '#7';

        // First probe (dir1)
        code += `( Step 1: Probe ${dir1Sign}${axis} )\n`;
        code += `G31 ${axis}${firstProbeVar} F#3 P#5 L${level} Q${qStop}  ( Fast )\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `G0 ${axis}${firstRetractInv}  ( Retract )\n`;
        code += `G31 ${axis}${firstSlowVar} F#4 P#5 L${level} Q${qStop}  ( Slow )\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `${firstEdgeVar}=1 ( Wash: prime )\n`;
        code += `${firstEdgeVar}=${axisResult}  ( Save first edge )\n`;
        code += `G0 ${axis}${firstRetractInv}  ( Retract from wall )\n\n`;

        if (findBoth) {
            // Fast probe across to opposite wall; stops on contact (continuous pocket behaviour)
            code += `( Fast probe to opposite wall )\n`;
            code += `G31 ${axis}${travelProbeVar} F#3 P#5 L${level} Q${qStop}  ( Fast probe across )\n`;
            code += `IF ${axisStatus}!=2 GOTO1  ( No contact = missed wall, abort )\n`;
            code += `G0 ${axis}${oppRetractInv}  ( Retract from wall )\n\n`;
        }

        // Second probe (opposite direction)
        code += `( Step 2: Probe ${dir2Sign}${axis} )\n`;
        if (!findBoth) {
            // Manual reposition mode: require fast probe to locate wall\n`;
            code += `G31 ${axis}${oppProbeVar} F#3 P#5 L${level} Q${qStop}  ( Fast )\n`;
            code += `IF ${axisStatus}!=2 GOTO1\n`;
            code += `G0 ${axis}${oppRetractInv}  ( Retract )\n`;
        }
        // Slow probe for precision (both modes)
        code += `G31 ${axis}${oppSlowVar} F#4 P#5 L${level} Q${qStop}  ( Slow )\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `${secondEdgeVar}=1 ( Wash: prime )\n`;
        code += `${secondEdgeVar}=${axisResult}  ( Save second edge )\n`;
        code += `G0 ${axis}${oppRetractInv}  ( Retract from wall )\n\n`;

        return code;
    }

    generateBossSequence(axis, dir1Sign, dir2Sign, axisStatus, axisResult, level, qStop, retract, findBoth, resultBase = 51) {
        let code = `( === BOSS: Probe from outside toward feature === )\n\n`;

        const firstEdgeVar = `#${resultBase}`;
        const secondEdgeVar = `#${resultBase + 1}`;
        const centerVar = `#${resultBase + 2}`;

        const firstProbeVar = (dir1Sign === '+') ? '#8' : '#7';
        const firstRetractInv = (dir1Sign === '+') ? '#9' : '#10';
        const firstSlowVar = (dir1Sign === '+') ? '#12' : '#11';
        const oppProbeVar = (dir2Sign === '+') ? '#8' : '#7';
        const oppRetractInv = (dir2Sign === '+') ? '#9' : '#10';
        const oppSlowVar = (dir2Sign === '+') ? '#12' : '#11';

        // First probe (dir1 - toward boss)
        code += `( Step 1: Probe ${dir1Sign}${axis} toward boss )\n`;
        code += `G31 ${axis}${firstProbeVar} F#3 P#5 L${level} Q${qStop}  ( Fast )\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `G0 ${axis}${firstRetractInv}  ( Retract )\n`;
        code += `G31 ${axis}${firstSlowVar} F#4 P#5 L${level} Q${qStop}  ( Slow )\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `${firstEdgeVar}=1 ( Wash: prime )\n`;
        code += `${firstEdgeVar}=${axisResult}  ( Save first edge )\n`;
        code += `G0 ${axis}${firstRetractInv}  ( Retract from edge )\n`;
        code += `#55=#882  ( Save current Z machine position )\n`;
        code += `G0 Z#17  ( Retract to safe Z )\n\n`;

        code += `( MANUAL REPOSITION REQUIRED )\n`;
        code += `( Jog probe to opposite side of boss )\n`;
        code += `( Z can be approximate - will auto-plunge to saved height )\n`;
        code += `#1505=1  ( Press Enter when in position )\n\n`;

        code += `( Plunge to saved probe height )\n`;
        code += `G53 G0 Z#55  ( Machine coord move to saved Z )\n\n`;

        // Second probe (same direction - toward boss from other side)
        code += `( Step 2: Probe ${dir2Sign}${axis} toward boss )\n`;
        code += `G31 ${axis}${oppProbeVar} F#3 P#5 L${level} Q${qStop}  ( Fast )\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `G0 ${axis}${oppRetractInv}  ( Retract )\n`;
        code += `G31 ${axis}${oppSlowVar} F#4 P#5 L${level} Q${qStop}  ( Slow )\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `${secondEdgeVar}=1 ( Wash: prime )\n`;
        code += `${secondEdgeVar}=${axisResult}  ( Save second edge )\n`;
        code += `G0 ${axis}${oppRetractInv}  ( Retract from edge )\n\n`;

        return code;
    }

    generateCenterCalculation(edgeVarA = 51, edgeVarB = 52, centerVar = 53) {
        let code = `( Calculate Center )\n`;
        code += `#${centerVar}=[#${edgeVarA}+#${edgeVarB}]/2  ( Average of two edges )\n\n`;
        return code;
    }

    generateWCSWrite(wcsLabel, axis, axisOffset, valueVar = '#53') {
        let code = `( Write to WCS )\n`;
        code += `#[#70+${axisOffset}]=${valueVar}  ( Set ${wcsLabel} ${axis} to center )\n\n`;
        return code;
    }

    generateFooter() {
        let footer = `G90  ( Back to absolute )\n`;
        footer += `#1505=-5000(Center found at #53!)\n`;
        footer += `GOTO2\n\n`;
        footer += `N1\n`;
        footer += `#1505=1(Probe failed - no contact!)\n`;
        footer += `G90\n\n`;
        footer += `N2\nM30\n`;
        return footer;
    }

    generateFinalRetract(axis, dirSign) {
        let code = `( Final retract )\n`;
        code += `G0 Z#17            ( Safe Z retract )\n\n`;
        return code;
    }
}
