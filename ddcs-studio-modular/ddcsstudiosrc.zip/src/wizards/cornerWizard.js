/**
 * DDCS Studio - Corner Wizard
 * Generates G-code for corner probing operations
 */

export class CornerWizard {
    constructor() {
        this.defaultScanDepth = 5;
    }

    // Helper: return signed expression string for a movement variable or number
    getSignedVar(sign, varName, invert=false) {
        const s = invert ? (sign === '+' ? '-' : '+') : sign;
        // for positive sign return varName (no leading +), for negative return -varName
        return (s === '+' ? '' : '-') + varName;
    }

    // Helper: parse numeric inputs safely
    toNum(v, def=0) {
        if (v === undefined || v === null) return def;
        const n = Number(v);
        return Number.isFinite(n) ? n : def;
    }

    generate(params) {
        const {
            corner,
            probeZ,
            syncA,
            slave,
            probeSeq,
            wcs,
            dist,
            retract,
            f_fast,
            f_slow,
            port,
            level,
            qStop,
            safeZ,
            clearance,
            travelDist
        } = params;

        // Normalize numeric params
        const _dist = this.toNum(dist, 0);
        const _retract = this.toNum(retract, 0);
        const _f_fast = this.toNum(f_fast, 0);
        const _f_slow = this.toNum(f_slow, 0);
        const _port = this.toNum(port, 0);
        const _level = this.toNum(level, 0);
        const _qStop = this.toNum(qStop, 0);
        const _safeZ = this.toNum(safeZ, 0);
        const _travelDist = this.toNum(travelDist, 0);
        const _clearance = this.toNum(clearance, 2);

        // Derive directions from corner location
        let xDir, yDir;
        if (corner === 'FL') {
            xDir = '+'; yDir = '+';
        } else if (corner === 'FR') {
            xDir = '-'; yDir = '+';
        } else if (corner === 'BL') {
            xDir = '+'; yDir = '-';
        } else if (corner === 'BR') {
            xDir = '-'; yDir = '-';
        }

        // WCS variable setup (strict variable mapping)
        let wcsCode = '';
        let wcsLabel = '';
        if (wcs === 'active') {
            wcsCode += `( Read Active WCS )\n#71=1 (Wash/Prime)\n#71=#578 (Read active WCS: 1=G54, 2=G55, etc)\n`;
            wcsCode += `#70=805+[#71-1]*5 (Base WCS address)\n\n`;
            wcsLabel = 'Active WCS';
        } else {
            const wcsMap = {
                'G54': 805, 'G55': 810, 'G56': 815,
                'G57': 820, 'G58': 825, 'G59': 830
            };
            wcsCode += `( Target: ${wcs} )\n#70=${wcsMap[wcs]} (Base WCS address)\n\n`;
            wcsLabel = wcs;
        }

        // Build G-code
        let gcode = this.generateHeader(corner, xDir, yDir, probeZ, wcsLabel, _dist, _retract, _travelDist, _f_fast, _f_slow, _safeZ);
        gcode += this.generateMotionVariables(_dist, _retract, _f_fast, _f_slow, _port, _clearance);
        gcode += this.generatePrecalcMotionVariables(_dist, _retract, _safeZ, _travelDist, this.defaultScanDepth);
        gcode += wcsCode;
        gcode += this.generateConfirmStart();
        gcode += `G91 ( INCREMENTAL MODE )\n\n`;

        let step = 1;

        // Optional Z surface probe
        if (probeZ) {
            gcode += this.generateZProbe(step, _level, _qStop, _retract, _safeZ, wcsLabel);
            step++;
        }

        // Probe sequence: YX or XY
        if (probeSeq === 'YX') {
            gcode += this.generateYXSequence(step, xDir, yDir, probeZ, _level, _qStop, _retract, _safeZ, _travelDist, wcsLabel);
        } else {
            gcode += this.generateXYSequence(step, xDir, yDir, probeZ, _level, _qStop, _retract, _safeZ, _travelDist, wcsLabel);
        }

        // Dual gantry sync (write to selected slave offset)
        if (syncA) {
            const s = slave || '3';
            gcode += `( Dual Gantry Sync )\n`;
            gcode += `G91 ( Incremental mode for sync )\n`;
            gcode += `G1 A0 F#3 ( Move A to 0 position )\n`;
            gcode += `G90 ( Back to absolute mode )\n`;
            // Write into dynamic WCS base + slave offset
            gcode += `#[#70+${s}]=#883 ( Sync A with Y )\n\n`;
        }

        gcode += this.generateFooter(corner);

        return gcode;
    }


    generateHeader(corner, xDir, yDir, probeZ, wcsLabel, dist, retract, travelDist, f_fast, f_slow, safeZ) {
        let header = `( Corner Finder | ${corner} | X${xDir} Y${yDir}`;
        if (probeZ) header += ` + Z Surface`;
        header += ` | ${wcsLabel} )\n`;
        header += `( DDCS M350 V10.0 - Pure Incremental Pattern )\n`;  
        header += `( User positioned probe correctly before starting )\n`;
        header += `( Max probe: ${dist}mm | Retract: ${retract}mm | Travel: ${travelDist}mm )\n`;
        header += `( Fast: ${f_fast} | Slow: ${f_slow} | SafeZ: ${safeZ}mm | Scan depth: ${this.defaultScanDepth}mm )\n\n`;
        return header;
    }

    generateMotionVariables(dist, retract, f_fast, f_slow, port, clearance) {
        // Include clearance (#6) to ensure downstream pre-calculations have a source
        let vars = `( Motion Variables - #1-#10 for seamless movement )\n`;
        vars += `#1=${dist} ( Max probe distance )\n`;
        vars += `#2=${retract} ( Retract after probe )\n`;
        vars += `#3=${f_fast} ( Fast speed )\n`;
        vars += `#4=${f_slow} ( Slow speed )\n`;
        vars += `#5=${port} ( Probe port )\n`;
        vars += `#6=${clearance || 2} ( Clearance/jog distance )\n\n`;
        return vars;
    }

    generatePrecalcMotionVariables(dist, retract, safeZ, travelDist, scanDepth) {
        const pd = parseInt(safeZ) + parseInt(scanDepth);
        const td = parseInt(travelDist) || 0;
        let vars = `( Pre-calculated motion values - #7-#19 )\n`;
        vars += `#7=[0-#1] ( Negative max probe )\n`;
        vars += `#8=#1     ( Positive max probe )\n`;
        vars += `#9=[0-#2] ( Negative retract )\n`;
        vars += `#10=#2    ( Positive retract )\n`;
        vars += `#11=[0-#2*2] ( Negative double retract )\n`;
        vars += `#12=[#2*2]   ( Positive double retract )\n`;
        vars += `#13=#6      ( Positive clearance )\n`;
        vars += `#14=[0-#6]  ( Negative clearance )\n`;
        vars += `#15=${td} ( Positive travel )\n`;
        vars += `#16=[0-${td}] ( Negative travel )\n`;
        vars += `#17=${pd} ( Plunge depth )\n`;
        vars += `#18=[0-#17] ( Negative plunge )\n`;
        vars += `#19=${safeZ} ( Safe Z )\n\n`;
        return vars;
    }

    generateConfirmStart() {
        return `( Confirm Start )\n#1505=1 (Press Enter to probe)\n\n`;
    }

    generateZProbe(step, level, qStop, retract, safeZ, wcsLabel) {
        // #1: Max probe dist, #2: Retract, #3: Fast, #4: Slow, #5: Port, #70: Base WCS, #60: temp, #62: temp
        let code = `( Step ${step}: Z Surface Probe )\n`;
        code += `G31 Z#7 F#3 P#5 L${level} Q${qStop} ( Fast probe down )\n`;
        code += `IF #1922!=2 GOTO1\n`;
        code += `G0 Z#10 ( Retract up )\n`;
        code += `G31 Z#11 F#4 P#5 L${level} Q${qStop} ( Slow probe )\n`;
        code += `IF #1922!=2 GOTO1\n`;
        code += `#[#70+2]=#1927 (Save ${wcsLabel} Z offset)\n`;
        // Final retract should move up, not dip; use positive retract (#10)
        code += `G0 Z#10 ( Retract up from surface )\n`;
        code += `G0 Z#19 ( Safe Z above surface )\n\n`;
        return code;
    }

    generateYXSequence(step, xDir, yDir, probeZ, level, qStop, retract, safeZ, travelDist, wcsLabel) {
        const scanDepth = this.defaultScanDepth;
        const plungeDepth = parseInt(safeZ) + parseInt(scanDepth);
        // Pre-calculated vars: #7/#8 probe, #9/#10 retract, #11/#12 double, #15/#16 travel, #17/#18 plunge, #19 safeZ
        const yProbeVar = (yDir === '+') ? '#8' : '#7';
        const yRetractVarInv = (yDir === '+') ? '#9' : '#10'; // invert retract (used right after fast probe)
        const ySlowVar = (yDir === '+') ? '#12' : '#11';
        const yRetractVar = yRetractVarInv; // same var name for readability
        const xProbeVar = (xDir === '+') ? '#8' : '#7';
        const xRetractVarInv = (xDir === '+') ? '#9' : '#10';
        const xSlowVar = (xDir === '+') ? '#12' : '#11';
        const travelPosVar = '#15';
        const travelNegVar = '#16';
        let code = '';
        // --- Y Probe ---
        code += `( Step ${step}: Y Probe )\n`;
        if (!probeZ) {
            code += `G0 Z#19 ( Safe Z )\n`;
        }
        code += `G0 Z#18 ( Down to scan depth )\n`;
        code += `G31 Y${yProbeVar} F#3 P#5 L${level} Q${qStop} ( Fast probe )\n`;
        code += `IF #1921!=2 GOTO1\n`;
        code += `G0 Y${yRetractVarInv} ( Retract )\n`;
        code += `G31 Y${ySlowVar} F#4 P#5 L${level} Q${qStop} ( Slow probe )\n`;
        code += `IF #1921!=2 GOTO1\n`;
        code += `#[#70+1]=#1926 (Save ${wcsLabel} Y offset)\n`;
        code += `G0 Y${yRetractVar} ( Retract from wall )\n`;
        code += `G0 Z#19 ( Safe Z above surface )\n\n`;
        step++;
        // --- Travel to X ---
        code += `( Step ${step}: Travel to X )\n`;
        // Clear Y edge by retract distance (signed)
        const clearYVar = (yDir === '+') ? '#10' : '#9';
        code += `G0 Y${clearYVar} ( Clear Y edge by ${retract}mm )\n`;
        // Move away in X by travelDist (opposite sign)
        const xTravelVar = (xDir === '+') ? travelNegVar : travelPosVar; // invert travel direction
        code += `G0 X${xTravelVar} ( Move away ${travelDist}mm in X )\n`;
        code += `G0 Z#18 ( Down to scan depth )\n\n`;
        step++;
        // --- X Probe ---
        code += `( Step ${step}: X Probe )\n`;
        code += `G31 X${xProbeVar} F#3 P#5 L${level} Q${qStop} ( Fast probe )\n`;
        code += `IF #1920!=2 GOTO1\n`;
        code += `G0 X${xRetractVarInv} ( Retract )\n`;
        code += `G31 X${xSlowVar} F#4 P#5 L${level} Q${qStop} ( Slow probe )\n`;
        code += `IF #1920!=2 GOTO1\n`;
        code += `#[#70+0]=#1925 (Save ${wcsLabel} X offset)\n`;
        code += `G0 X${xRetractVarInv} ( Retract from wall )\n`;
        code += `G0 Z#19 ( Safe Z above surface )\n\n`;
        return code;
    }

    generateXYSequence(step, xDir, yDir, probeZ, level, qStop, retract, safeZ, travelDist, wcsLabel) {
        const scanDepth = this.defaultScanDepth;
        const plungeDepth = parseInt(safeZ) + parseInt(scanDepth);
        // Pre-calculated vars: #7/#8 probe, #9/#10 retract, #11/#12 double, #15/#16 travel, #17/#18 plunge, #19 safeZ
        const xProbeVar = (xDir === '+') ? '#8' : '#7';
        const xRetractVarInv = (xDir === '+') ? '#9' : '#10';
        const xSlowVar = (xDir === '+') ? '#12' : '#11';
        const yProbeVar = (yDir === '+') ? '#8' : '#7';
        const yRetractVarInv = (yDir === '+') ? '#9' : '#10';
        const ySlowVar = (yDir === '+') ? '#12' : '#11';
        const travelPosVar = '#15';
        const travelNegVar = '#16';
        let code = '';
        // --- X Probe ---
        code += `( Step ${step}: X Probe )\n`;
        if (!probeZ) {
            code += `G0 Z#19 ( Safe Z )\n`;
        }
        code += `G0 Z#18 ( Down to scan depth )\n`;
        code += `G31 X${xProbeVar} F#3 P#5 L${level} Q${qStop} ( Fast probe )\n`;
        code += `IF #1920!=2 GOTO1\n`;
        code += `G0 X${xRetractVarInv} ( Retract )\n`;
        code += `G31 X${xSlowVar} F#4 P#5 L${level} Q${qStop} ( Slow probe )\n`;
        code += `IF #1920!=2 GOTO1\n`;
        code += `#[#70+0]=#1925 (Save ${wcsLabel} X offset)\n`;
        code += `G0 X${xRetractVarInv} ( Retract from wall )\n`;
        code += `G0 Z#19 ( Safe Z above surface )\n\n`;
        step++;
        // --- Travel to Y ---
        code += `( Step ${step}: Travel to Y )\n`;
        // Clear X edge by retract distance (signed)
        const clearXVar = (xDir === '+') ? '#10' : '#9';
        code += `G0 X${clearXVar} ( Clear X edge by ${retract}mm )\n`;
        // Move away in Y by travelDist (opposite sign)
        const yTravelVar = (yDir === '+') ? travelNegVar : travelPosVar;
        code += `G0 Y${yTravelVar} ( Move away ${travelDist}mm in Y )\n`;
        code += `G0 Z#18 ( Down to scan depth )\n\n`;
        step++;
        // --- Y Probe ---
        code += `( Step ${step}: Y Probe )\n`;
        code += `G31 Y${yProbeVar} F#3 P#5 L${level} Q${qStop} ( Fast probe )\n`;
        code += `IF #1921!=2 GOTO1\n`;
        code += `G0 Y${yRetractVarInv} ( Retract )\n`;
        code += `G31 Y${ySlowVar} F#4 P#5 L${level} Q${qStop} ( Slow probe )\n`;
        code += `IF #1921!=2 GOTO1\n`;
        code += `#[#70+1]=#1926 (Save ${wcsLabel} Y offset)\n`;
        code += `G0 Y${yRetractVarInv} ( Retract from wall )\n`;
        code += `G0 Z#19 ( Safe Z above surface )\n\n`;
        return code;
    }

    generateFooter(corner) {
        let footer = `G90 ( Back to absolute )\n`;
        footer += `#1505=-5000 (Corner ${corner} Found!)\nGOTO2\n\n`;
        footer += `N1\n#1505=1 (Probe Failed!)\n`;
        footer += `G91 G0 Z${parseInt(this.defaultScanDepth) + parseInt(5)} ( Safe Z )\n`;
        footer += `G90\n\nN2\nM30\n`;
        return footer;
    }
}
