/**
 * DDCS Studio - Edge Wizard
 * Generates G-code for single edge probing operations
 */

export class EdgeWizard {
    constructor() {
        // No special initialization needed
    }

    generate(params) {
        const {
            axis,       // 'X' or 'Y'
            dir,        // 'pos' or 'neg'
            wcs,        // WCS target
            dist,       // Max probe distance
            retract,    // Retract distance
            clearance,  // Clearance / additional jog distance when finding opposite
            findBoth,   // If true, auto-jog and probe opposite edge
            syncA,      // dual gantry sync
            slave,      // slave selection for dual gantry
            f_fast,     // Fast feed rate
            f_slow,     // Slow feed rate
            port,       // Probe input port
            level,      // Probe level (0 or 1)
            qStop       // Stop mode (0 or 1)
        } = params;

        // Axis-specific probe status and result variables
        const axisStatus = axis === 'X' ? '#1920' : '#1921';
        const axisResult = axis === 'X' ? '#1925' : '#1926';
        const axisOffset = axis === 'X' ? 0 : 1;

        // Direction signs
        const dirSign = dir === 'pos' ? '+' : '-';
        const retractSign = dir === 'pos' ? '-' : '+';

        // Generate WCS code
        const { wcsCode, wcsLabel } = this.generateWCSCode(wcs);

        // Build G-code
        let gcode = this.generateHeader(axis, dirSign, wcsLabel, dist, retract, f_fast, f_slow, findBoth);
        gcode += this.generateMotionVariables(dist, retract, f_fast, f_slow, port, clearance);
        gcode += this.generatePrecalcMotionVariables(dist, retract, '0', clearance, 0, 0);
        gcode += wcsCode;
        gcode += this.generateConfirmStart(axis, dirSign);
        gcode += `G91  ( Incremental mode )\n\n`;
        gcode += this.generateFastProbe(axis, dirSign, axisStatus, level, qStop);
        gcode += this.generateRetract(axis, retractSign);
        gcode += this.generateSlowProbe(axis, dirSign, axisStatus, axisResult, level, qStop);

        if (findBoth) {
            // save first edge in #50 already done in slow probe
            // auto-travel to opposite side and probe again into #51
            const dirOppSign = dir === 'pos' ? '-' : '+';
            gcode += `( Auto-travel to opposite edge )\n`;
            const travelProbeVar = (dirOppSign === '+') ? '#8' : '#7';
            const travelClearVar = (dirOppSign === '+') ? '#13' : '#14';
            gcode += `G0 ${axis}${travelProbeVar}  ( Move across by max probe distance )\n`;
            gcode += `G0 ${axis}${travelClearVar}  ( Additional clearance )\n\n`;
            gcode += `( Step: Probe opposite edge )\n`;
            gcode += this.generateFastProbe(axis, dirOppSign, axisStatus, level, qStop);
            gcode += this.generateRetract(axis, (dirOppSign === '+') ? '-' : '+');
            // Slow probe into second result
            gcode += `( Slow Probe - Opposite )\n`;
            const oppDoubleVar = (dirOppSign === '+') ? '#12' : '#11';
            gcode += `G31 ${axis}${oppDoubleVar} F#4 P#5 L${level} Q${qStop}\n`;
            gcode += `IF ${axisStatus}!=2 GOTO1\n`;
            gcode += `#51=1 ( Wash: prime )\n`;
            gcode += `#51=${axisResult}  ( Save opposite edge )\n`;
            const oppRetractVar = (dirOppSign === '+') ? '#9' : '#10';
            gcode += `G0 ${axis}${oppRetractVar}  ( Retract from opposite edge )\n\n`;

            // Compute width and center
            gcode += `( Compute width and center )\n`;
            gcode += `#54=[#51-#50]  ( OppositeEdge - Edge )\n`;
            gcode += `#53=[#50+#51]/2  ( Center between edges )\n\n`;
        }

        gcode += this.generateWCSWrite(wcsLabel, axis, axisOffset, findBoth);

        // Dual gantry sync support for edge probes
        if (syncA) {
            const s = slave || '3';
            gcode += `( Dual Gantry Sync )\n`;
                gcode += `#[#70+${s}]=#883  ( Write sync result to slave offset )\n\n`;
        }

        gcode += this.generateFinalRetract(axis, retractSign);
        gcode += this.generateFooter();

        return gcode;
    }

    generateWCSCode(wcs) {
        let wcsCode = '';
        let wcsLabel = '';

        if (wcs === 'active') {
            wcsCode = `( Read Active WCS )\n#71=1 ( Wash: prime )\n#71=#578 ( Read active WCS: 1=G54, 2=G55, etc )\n`;
                wcsCode += `#70=805+[#71-1]*5  ( Calculate base address )\n\n`;
            wcsLabel = 'Active WCS';
        } else {
            const wcsMap = {
                'G54': 805, 'G55': 810, 'G56': 815,
                'G57': 820, 'G58': 825, 'G59': 830
            };
            const baseAddr = wcsMap[wcs];
                wcsCode = `( Target: ${wcs} )\n#70=${baseAddr}  ( Base address )\n\n`;
            wcsLabel = wcs;
        }

        return { wcsCode, wcsLabel };
    }

    generateHeader(axis, dirSign, wcsLabel, dist, retract, f_fast, f_slow) {
        let header = `( Edge Finder | ${axis}${dirSign} | ${wcsLabel} )\n`;
        header += `( DDCS M350 V10.0 Compliant )\n`;  
        header += `( Distance: ${dist}mm | Retract: ${retract}mm | Fast: ${f_fast} | Slow: ${f_slow} )\n\n`;
        return header;
    }

    generateMotionVariables(dist, retract, f_fast, f_slow, port, clearance) {
        let vars = `( Motion Variables - #1-#10 for seamless movement )\n`;
        vars += `#1=${dist}      ( Max probe distance )\n`;
        vars += `#2=${retract}   ( Retract distance )\n`;
        vars += `#3=${f_fast}    ( Fast feed )\n`;
        vars += `#4=${f_slow}    ( Slow feed )\n`;
        vars += `#5=${port}      ( Probe port )\n`;
        vars += `#6=${clearance || 2} ( Clearance/jog distance )\n`;
        vars += `( Result storage )\n`;
        vars += `#50=0            ( Edge result )\n`;
        vars += `#51=0            ( Opposite edge result )\n`;
        vars += `#54=0            ( Width )\n\n`;
        return vars;
    }

    generatePrecalcMotionVariables(dist, retract, safeZ, clearance, travelDist, scanDepth) {
        // dist -> #1, retract -> #2, clearance -> #6
        const td = parseInt(travelDist) || 0;
        let vars = `( Pre-calculated motion values - #7-#19 )\n`;
        vars += `#7=[0-#1] ( Negative max probe )\n`;
        vars += `#8=#1     ( Positive max probe )\n`;
        vars += `#9=[0-#2] ( Negative retract )\n`;
        vars += `#10=#2    ( Positive retract )\n`;
        vars += `#11=[0-#2*2] ( Negative double retract )\n`;
        vars += `#12=[#2*2]   ( Positive double retract )\n`;
        vars += `#13=#6      ( Positive clearance )\n`;
        vars += `#14=[0-#6]  ( Negative clearance )\n`;
        vars += `#15=${td} ( Positive travel )\n`;
        vars += `#16=[0-${td}] ( Negative travel )\n\n`;
        return vars;
    }

    generateConfirmStart(axis, dirSign) {
        return `( Confirm Start )\n#1505=1 (Press Enter to probe ${axis}${dirSign})\n\n`;
    }

    generateFastProbe(axis, dirSign, axisStatus, level, qStop) {
        let code = `( Fast Probe )\n`;
        const probeVar = (dirSign === '+') ? '#8' : '#7';
        code += `G31 ${axis}${probeVar} F#3 P#5 L${level} Q${qStop}\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n\n`;
        return code;
    }

    generateRetract(axis, retractSign) {
        let code = `( Retract )\n`;
        const retractVar = (retractSign === '+') ? '#10' : '#9';
        code += `G0 ${axis}${retractVar}\n\n`;
        return code;
    }

    generateSlowProbe(axis, dirSign, axisStatus, axisResult, level, qStop) {
        let code = `( Slow Probe )\n`;
        const doubleVar = (dirSign === '+') ? '#12' : '#11';
        code += `G31 ${axis}${doubleVar} F#4 P#5 L${level} Q${qStop}\n`;
        code += `IF ${axisStatus}!=2 GOTO1\n`;
        code += `#50=1 ( Wash: prime )\n`;
        code += `#50=${axisResult}  ( Save edge position )\n\n`;
        return code;
    }

    generateWCSWrite(wcsLabel, axis, axisOffset, findBoth) {
        let code = `( Write to WCS )\n`;
        const src = findBoth ? '#53' : '#50';
        const label = findBoth ? 'center' : 'edge';
            code += `#[#70+${axisOffset}]=${src}  ( Set ${wcsLabel} ${axis} to ${label} )\n\n`;
        return code;
    }

    // Use precomputed retract variables (#10/#9) to avoid inline sign+variable
    // Avoid using a positive sign immediately before a variable (e.g., axis + #var). This form is disallowed by DDCS M350.
    // Negative signed variables (axis - #var) are permitted by community macros.
    generateFinalRetract(axis, retractSign) {
        let code = `( Retract from edge )\n`;
        const retractVar = (retractSign === '+') ? '#10' : '#9';
        code += `G0 ${axis}${retractVar}\n\n`;
        return code;
    }

    generateFooter() {
        let footer = `G90  ( Back to absolute )\n`;
        footer += `#1505=-5000(Edge found!)\n`;
        footer += `GOTO2\n\n`;
        footer += `N1\n`;
        footer += `#1505=1(Probe failed - no contact!)\n`;
        footer += `G90\n\n`;
        footer += `N2\nM30\n`;
        return footer;
    }
}
