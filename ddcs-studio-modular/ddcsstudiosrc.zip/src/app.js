/**
 * DDCS Studio - Main Application
 * Version 9.49 - Modular ES6 Edition
 * 
 * CNC G-code Generator for DDCS Expert M350 Controller
 */

import { ThemeManager } from './themes.js';
import { ScaleManager } from './scaleManager.js';
import { VariableDatabase } from './variableDB.js';
import { EditorManager } from './editorManager.js';
import { DockManager } from './dockManager.js';
import { WizardManager } from './wizardManager.js';
import { el } from './uiUtils.js';

// MiddleViz helpers (animation, id mapping, visibility controller)
import './middleVizUtils.js';
import './middleVizAnimator.js';
import './middleVizManager.js';

class DDCSStudio {
    constructor() {
        this.themeManager = new ThemeManager();
        console.debug('DDCSStudio: ThemeManager initialized');
        this.scaleManager = new ScaleManager();
        console.debug('DDCSStudio: ScaleManager initialized');
        this.variableDB = new VariableDatabase();
        console.debug('DDCSStudio: VariableDatabase initialized');
        this.editorManager = new EditorManager();
        console.debug('DDCSStudio: EditorManager initialized');
        this.dockManager = new DockManager(this.variableDB, this.editorManager);
        console.debug('DDCSStudio: DockManager initialized');
        this.wizardManager = new WizardManager(this.editorManager);
        console.debug('DDCSStudio: WizardManager initialized');

        console.debug('DDCSStudio: calling init()');
        this.init();
    }

    init() {
        console.debug('DDCSStudio.init() start');
        // Setup global window functions for backwards compatibility
        this.setupGlobalFunctions();
        console.debug('DDCSStudio.init() - setupGlobalFunctions complete');

        // Setup file upload handler
        this.setupFileUpload();

        // Setup window resize handler
        window.addEventListener('resize', () => {
            if (this.scaleManager.isAutoScale()) {
                this.scaleManager.apply();
            }
        });

        // Visual Viewport -> detect virtual keyboard on mobile (adds/removes `keyboard-active` on <body>)
        if (window.visualViewport) {
            const _checkKeyboard = () => {
                try {
                    const vv = window.visualViewport;
                    if (vv && vv.height < window.innerHeight * 0.8) {
                        document.body.classList.add('keyboard-active');
                    } else {
                        document.body.classList.remove('keyboard-active');
                    }
                } catch (e) { /* noop */ }
            };
            window.visualViewport.addEventListener('resize', _checkKeyboard);
            window.visualViewport.addEventListener('scroll', _checkKeyboard);
            // initial check
            _checkKeyboard();
        }

        // Apply initial scale
        this.scaleManager.apply();

        // Initialize corner visualization
        this.initializeCornerVisualization();
        this.setupVisualizationListeners();

        // Log layout snapshot for debugging: sizes, transforms, and visibility
        window.addEventListener('scaleChanged', (ev) => {
            console.debug('scaleChanged event received', ev.detail);
            this.logLayoutSnapshot();
        });
        // initial snapshot
        this.logLayoutSnapshot();
    }

    logLayoutSnapshot() {
        try {
            const bodyScale = document.body.getAttribute('data-scale');
            const bodyStyle = getComputedStyle(document.body);
            const appShell = document.querySelector('.app-shell');
            const main = document.querySelector('.main');
            const editor = document.getElementById('editor');
            const varList = document.getElementById('varList');
            const wizard = document.getElementById('wizard');

            const shellRect = appShell ? appShell.getBoundingClientRect() : null;
            const mainRect = main ? main.getBoundingClientRect() : null;
            const editorRect = editor ? editor.getBoundingClientRect() : null;

            console.debug('LayoutSnapshot', {
                bodyScale,
                bodyTransform: bodyStyle.transform,
                bodyClient: { w: document.body.clientWidth, h: document.body.clientHeight },
                appShellTransform: appShell ? getComputedStyle(appShell).transform : null,
                appShellRect: shellRect && { x: Math.round(shellRect.x), y: Math.round(shellRect.y), w: Math.round(shellRect.width), h: Math.round(shellRect.height) },
                mainRect: mainRect && { x: Math.round(mainRect.x), y: Math.round(mainRect.y), w: Math.round(mainRect.width), h: Math.round(mainRect.height) },
                editorRect: editorRect && { w: Math.round(editorRect.width), h: Math.round(editorRect.height) },
                editorClientHeight: editor ? editor.clientHeight : null,
                varListChildCount: varList ? varList.querySelectorAll('.var-item').length : 0,
                wizardDisplay: wizard ? getComputedStyle(wizard).display : 'missing'
            });
        } catch (err) {
            console.warn('logLayoutSnapshot failed', err);
        }
    }

    setupGlobalFunctions() {
        // Expose key functions to global scope for HTML onclick handlers
        window.toggleStyle = () => this.themeManager.toggle();
        window.toggleScale = () => this.scaleManager.toggle();
        window.copyCode = () => this.editorManager.copyCode();
        window.clearCode = () => this.editorManager.clearCode();
        window.downloadFile = () => this.editorManager.downloadFile();
        window.clearSearch = () => this.dockManager.clear();
        window.insert = (key, text) => this.editorManager.insert(key, text);
        window.backspace = () => this.editorManager.backspace();

        // Wizard functions
        window.openWiz = (type) => this.wizardManager.open(type);
        window.openCornerWiz = () => this.wizardManager.openCorner();
        window.openMiddleWiz = () => this.wizardManager.openMiddle();
        window.openEdgeWiz = () => this.wizardManager.openEdge();
        window.closeWiz = () => this.wizardManager.close();
        window.insertWiz = () => this.wizardManager.insert();
        window.togglePreview = () => this.wizardManager.togglePreview();
        window.updateWiz = () => this.wizardManager.update();

        // Insert in message function for wizards
        window.insertInMsg = (t) => {
            const i = el('c_msg');
            if (i) {
                i.value = i.value.slice(0, i.selectionStart) + t + i.value.slice(i.selectionEnd);
                this.wizardManager.update();
                i.focus();
            }
        };
    }

    setupFileUpload() {
        const csvInput = el('csvInput');
        if (!csvInput) return;

        csvInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = (e) => {
                this.variableDB.loadFromCSV(e.target.result);
            };
            reader.readAsText(file);
        });
    }

    initializeCornerVisualization() {
        document.addEventListener('DOMContentLoaded', () => {
            const cornerVizCorner = document.getElementById('cornerVizCorner');
            if (cornerVizCorner) {
                ['cornerFL', 'cornerFR', 'cornerBL', 'cornerBR'].forEach(cornerId => {
                    const corner = cornerVizCorner.querySelector('#' + cornerId);
                    if (corner) {
                        const yxSeq = corner.querySelector('[id^="probeYX"]');
                        const xySeq = corner.querySelector('[id^="probeXY"]');
                        if (yxSeq) yxSeq.style.display = 'none';
                        if (xySeq) xySeq.style.display = 'none';
                    }
                });
            }
        });
    }

    setupVisualizationListeners() {
        // Corner wizard visualization listeners
        ['c_corner', 'c_probe_seq', 'c_probe_z'].forEach(id => {
            const elem = el(id);
            if (elem) {
                elem.addEventListener('change', () => {
                    if (el('wiz_corner').style.display !== 'none') {
                        if (window.drawCornerViz) {
                            window.drawCornerViz();
                        }
                    }
                });
            }
        });

        // Middle wizard visualization listeners
        ['m_type', 'm_axis', 'm_dir', 'm_dir2', 'm_both'].forEach(id => {
            const elem = el(id);
            if (elem) {
                elem.addEventListener('change', () => {
                    if (el('wiz_middle').style.display !== 'none') {
                        if (window.drawMiddleViz) {
                            window.drawMiddleViz();
                        }
                    }
                });
            }
        });

        // Edge/probe visualization listeners
        ['p_axis', 'p_dir', 'p_mode', 'p_type', 'p_probe_both', 'p_corner', 'p_probe_seq'].forEach(id => {
            const elem = el(id);
            if (elem) {
                elem.addEventListener('change', () => {
                    const mode = el('p_mode')?.value;
                    if (mode === 'edge' || mode === 'center' || mode === 'corner') {
                        if (window.drawProbeViz) {
                            window.drawProbeViz();
                        }
                    }
                });
            }
        });
    }

    openCorner() {
        this.open('corner');
        setTimeout(() => {
            if (window.drawCornerViz) window.drawCornerViz();
            this.updateCornerWizard();
        }, 10);
    }

    openMiddle() {
        this.open('middle');
        setTimeout(() => {
            if (window.drawMiddleViz) window.drawMiddleViz();
            this.updateMiddleWizard();
        }, 10);
    }

    openEdge() {
        this.open('edge');
        setTimeout(() => {
            if (window.drawProbeViz) window.drawProbeViz();
            this.updateEdgeWizard();
        }, 10);
    }
}

// Initialize application when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.ddcsStudio = new DDCSStudio();
    });
} else {
    window.ddcsStudio = new DDCSStudio();
}

export default DDCSStudio;
