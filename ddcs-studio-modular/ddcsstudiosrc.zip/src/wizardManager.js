/**
 * DDCS Studio Wizard Manager
 * Coordinates all wizard dialogs and code generation
 */

import { el, UIUtils } from './uiUtils.js';
import { CornerWizard } from './wizards/cornerWizard.js';
import { MiddleWizard } from './wizards/middleWizard.js';
import { EdgeWizard } from './wizards/edgeWizard.js';
import { CommunicationWizard } from './wizards/communicationWizard.js';
import { WCSWizard } from './wizards/wcsWizard.js';

export class WizardManager {
    constructor(editorManager) {
        this.editorManager = editorManager;
        this.cornerWizard = new CornerWizard();
        this.middleWizard = new MiddleWizard();
        this.edgeWizard = new EdgeWizard();
        this.communicationWizard = new CommunicationWizard();
        this.wcsWizard = new WCSWizard();
        this.wizardElement = el('wizard');
        console.debug('WizardManager: constructor - created wizards, wizardElement=', !!this.wizardElement);
        // Defensive: only setup listeners if wizard container is present
        if (this.wizardElement) {
            this.setupEventListeners();
            console.debug('WizardManager: event listeners set up');
        } else {
            console.warn('WizardManager: wizard element (#wizard) not found');
        }
    }

    setupEventListeners() {
        // Click outside wizard to close
        this.wizardElement.addEventListener('click', (e) => {
            if (e.target.id === 'wizard') {
                this.close();
            }
        });

        // Escape key to close wizard
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                if (this.wizardElement && this.wizardElement.classList.contains('active')) {
                    this.close();
                    e.preventDefault();
                }
            }
        });

        // Setup input listeners for all wizard controls
        this.setupWizardInputListeners();
    }

    setupWizardInputListeners() {
        const wizInputs = [
            'c_type', 'c_msg', 'c_val', 'c_id', 'c_dest', 'c_popup_mode',
            'c_slot1', 'c_slot2', 'c_slot3', 'c_slot4',
            'w_sys', 'w_x', 'w_y', 'w_z', 'w_a', 'w_sync', 'w_slave',
            'p_mode', 'p_axis', 'p_dir', 'p_dist', 'p_feed_fast', 'p_feed_slow',
            'p_back', 'p_retract', 'p_type', 'p_hop', 'p_port', 'p_level', 'p_q',
            'p_corner', 'p_probe_z', 'p_sync_a', 'p_probe_seq', 'p_wcs',
            'p_approach', 'p_x_approach', 'p_y_approach', 'p_scan_depth',
            'p_travel_dist', 'p_edge_clear', 'p_both', 'p_safe_z',
            'p_slave',
            'c_corner', 'c_probe_seq', 'c_probe_z', 'c_sync_a', 'c_wcs',
            'c_travel_dist', 'c_safe_z', 'c_feed_fast', 'c_feed_slow',
            'c_dist', 'c_retract', 'c_port', 'c_level', 'c_q',
            'c_slave',
            'm_type', 'm_axis', 'm_dir', 'm_dir2', 'm_both', 'm_sync_a', 'm_wcs',
            'm_slave',
            'm_dist', 'm_retract', 'm_safe_z', 'm_clearance',
            'm_feed_fast', 'm_feed_slow', 'm_port', 'm_level', 'm_q',
            'e_axis', 'e_dir', 'e_wcs', 'e_dist', 'e_retract',
            'e_feed_fast', 'e_feed_slow', 'e_port', 'e_level', 'e_q'
        ];

        wizInputs.forEach(id => {
            const element = el(id);
            if (element) {
                element.addEventListener('input', () => this.update());
                // Some controls (like checkboxes) are more reliable with 'change' events in certain environments
                element.addEventListener('change', () => this.update());
            }
        });
    }

    open(type) {
        const box = document.querySelector('.wiz-box');
        console.debug('WizardManager.open()', type, 'wizardElement=', this.wizardElement);
        if (!this.wizardElement) {
            console.warn('WizardManager.open(): no wizard container available');
            return;
        }
        
        if (type === 'probe' || type === 'corner' || type === 'middle' || type === 'edge') {
            box.classList.add('large');
        } else {
            box.classList.remove('large');
        }

        // Ensure overlay is visible and mark active
        this.wizardElement.style.display = 'flex';
        this.wizardElement.classList.add('active');
        
        // Hide all wizard panels
        ['wiz_comm', 'wiz_wcs', 'wiz_corner', 'wiz_middle', 'wiz_edge'].forEach(id => {
            const elem = el(id);
            if (elem) elem.style.display = 'none';
        });

        // Show requested wizard
        const wizElem = el('wiz_' + type);
        if (wizElem) {
            wizElem.style.display = 'block';
            // Ensure fields & preview reflect current defaults immediately
            this.update();
        }

    }

    openCorner() {
        this.open('corner');
        setTimeout(() => {
            if (window.drawCornerViz) window.drawCornerViz();
            this.updateCornerWizard();
        }, 50);
    }

    openMiddle() {
        this.open('middle');
        setTimeout(() => {
            if (window.drawMiddleViz) window.drawMiddleViz();
            this.updateMiddleWizard();
        }, 50);
    }

    openEdge() {
        this.open('edge');
        setTimeout(() => {
            if (window.drawProbeViz) window.drawProbeViz();
            this.updateEdgeWizard();
        }, 50);
    }

    close() {
        // Hide overlay and clear active state
        this.wizardElement.classList.remove('active');
        this.wizardElement.style.display = 'none';
    }

    update() {
        // Defensive: some environments may call update() before all wizard panels exist in DOM
        const wizVisible = (id) => {
            const e = el(id);
            return e ? e.style.display !== 'none' : false;
        };

        const wizComm = wizVisible('wiz_comm');
        const wizWcs = wizVisible('wiz_wcs');
        const wizCorner = wizVisible('wiz_corner');
        const wizMiddle = wizVisible('wiz_middle');
        const wizEdge = wizVisible('wiz_edge');

        if (wizComm) {
            this.updateCommunicationWizard();
        } else if (wizWcs) {
            this.updateWCSWizard();
        } else if (wizCorner) {
            this.updateCornerWizard();
        } else if (wizMiddle) {
            this.updateMiddleWizard();
        } else if (wizEdge) {
            this.updateEdgeWizard();
        }
    }

    updateCommunicationWizard() {
        const type = el('c_type').value;
        const params = {
            type: type,
            msg: el('c_msg')?.value || '',
            val: el('c_val')?.value || '',
            popupMode: el('c_popup_mode')?.value || '',
            id: el('c_id')?.value || '',
            dest: el('c_dest')?.value || '',
            slot1: el('c_slot1')?.value || '',
            slot2: el('c_slot2')?.value || '',
            slot3: el('c_slot3')?.value || '',
            slot4: el('c_slot4')?.value || ''
        };

        // Update field visibility
        const visibility = this.communicationWizard.getFieldVisibility(type);
        const modeBlock = el('c_mode_block');
        const valBlock = el('c_val_block');
        const msgBlock = el('c_msg_block');
        const slotsBlock = el('c_slots_block');
        const varBlock = el('c_var_block');

        if (modeBlock) modeBlock.classList.toggle('hidden', !visibility.showMode);
        if (valBlock) valBlock.classList.toggle('hidden', !visibility.showValue);
        if (msgBlock) msgBlock.classList.toggle('hidden', !visibility.showMessage);
        if (slotsBlock) slotsBlock.classList.toggle('hidden', !visibility.showSlots);
        if (varBlock) varBlock.classList.toggle('hidden', !visibility.showVar);

        const gcode = this.communicationWizard.generate(params);
        el('wiz_comm_code').innerHTML = gcode;
    }

    updateWCSWizard() {
        const params = {
            sys: el('w_sys').value,
            axisX: el('w_x')?.checked || false,
            axisY: el('w_y')?.checked || false,
            axisZ: el('w_z')?.checked || false,
            axisA: el('w_a')?.checked || false,
            sync: el('w_sync')?.checked || false,
            slave: el('w_slave')?.value || '3'
        };

        const gcode = this.wcsWizard.generate(params);
        el('wiz_wcs_code').innerHTML = UIUtils.formatGCode(gcode);

        // Update status label with human-friendly WCS name and base address
        const wcsStatus = el('wcsStatus');
        if (wcsStatus) wcsStatus.textContent = `${this.wcsWizard.getWCSName(params.sys)} - Base: ${this.wcsWizard.getWCSBase(params.sys)}`;
    }

    updateCornerWizard() {
        // Debug: log entry and the main controls we care about
        console.debug('updateCornerWizard called', {
            corner: el('c_corner')?.value,
            probeZ: el('c_probe_z')?.checked,
            probeSeq: el('c_probe_seq')?.value
        });

        const params = {
            corner: el('c_corner').value,
            probeZ: el('c_probe_z').checked,
            syncA: el('c_sync_a').checked,
            slave: el('c_slave')?.value || '3',
            probeSeq: el('c_probe_seq').value,
            wcs: el('c_wcs').value,
            dist: el('c_dist').value,
            retract: el('c_retract').value,
            f_fast: el('c_feed_fast').value,
            f_slow: el('c_feed_slow').value,
            port: el('c_port').value,
            level: el('c_level').value,
            qStop: el('c_q').value,
            safeZ: el('c_safe_z').value,
            travelDist: el('c_travel_dist').value
        };

        const gcode = this.cornerWizard.generate(params);
        el('wiz_corner_code').innerHTML = UIUtils.formatGCode(gcode);

        // Debug: indicate whether generated gcode contains Z probe sequence
        const containsZ = /(Step \d+: Z Surface Probe|G31 Z)/.test(gcode);
        console.debug('cornerWizard.generate => containsZProbe=', containsZ);

        // Update corner status label 📌
        const dirMap = { FL: 'X+,Y+', FR: 'X-,Y+', BL: 'X+,Y-', BR: 'X-,Y-' };
        const cornerStatus = el('cornerVizStatus');
        if (cornerStatus) cornerStatus.textContent = `Corner: ${params.corner} (${dirMap[params.corner]}) - ${params.probeSeq}` + (params.probeZ ? ' + Z' : '');

        // Update visualization if function exists (pass probeZ so draw function can hide/show Z elements)
        if (window.drawCornerViz) {
            window.drawCornerViz(params.probeZ);
        }
    }

    async updateMiddleWizard() {
        const dir1val = el('m_dir')?.value || 'pos';
        const dir2val = el('m_dir2')?.value || (dir1val === 'pos' ? 'neg' : 'pos');

        const params = {
            featureType: el('m_type')?.value || 'pocket',
            axis: el('m_axis')?.value || 'X',
            dir1: dir1val,
            dir2: dir2val,
            findBoth: el('m_both')?.checked || false,
            syncA: el('m_sync_a')?.checked || false,
            slave: el('m_slave')?.value || '3',
            wcs: el('m_wcs')?.value || 'G54',
            dist: el('m_dist')?.value || '20',
            retract: el('m_retract')?.value || '2',
            safeZ: el('m_safe_z')?.value || '10',
            clearance: el('m_clearance')?.value || '2',
            f_fast: el('m_feed_fast')?.value || '200',
            f_slow: el('m_feed_slow')?.value || '50',
            port: el('m_port')?.value || '3',
            level: el('m_level')?.value || '0',
            qStop: el('m_q')?.value || '1'
        };

        // Show/hide secondary direction control when Find Both is enabled
        const dir2Block = el('m_dir2_block');
        const dir2El = el('m_dir2');
        if (dir2Block) dir2Block.classList.toggle('hidden', !params.findBoth);
        if (params.findBoth && dir2El) dir2El.value = dir2val;

        const gcode = this.middleWizard.generate(params);
        el('wiz_middle_code').innerHTML = UIUtils.formatGCode(gcode);

        // Update middle status label
        const middleStatus = el('middleVizStatus');
        const dirLabel = params.dir1 === 'pos' ? 'pos' : 'neg';
        const bothLabel = params.findBoth ? ` (both: ${params.dir1}/${params.dir2})` : '';
        if (middleStatus) middleStatus.textContent = `Middle: ${params.featureType} | ${params.axis} ${dirLabel}${bothLabel}`;

        // Update visualization if function exists — await SVG injection so autoplay can find elements
        if (window.drawMiddleViz) {
            console.debug('updateMiddleWizard: calling drawMiddleViz and awaiting completion');
            await window.drawMiddleViz();
            console.debug('updateMiddleWizard: drawMiddleViz complete');
        }

        // Autoplay simulation when Middle wizard is opened — use resolveVizIds + PathAnimator if available
        if (window.resolveVizIds && window.PathAnimator) {
            try {
                const vizIds = window.resolveVizIds({
                    featureType: params.featureType,
                    axis: params.axis,
                    dir1: params.dir1,
                    twoAxis: !!params.findBoth
                });
                console.debug('updateMiddleWizard: resolved vizIds', vizIds);

                const animInput = {
                    probePath: vizIds.probePathSelector || vizIds.probePathId,
                    retractPath: vizIds.retractPathSelector || (vizIds.retractCandidates && vizIds.retractCandidates[0]) || null,
                    jogPath: vizIds.jogPathSelector || vizIds.jogPathId || null,
                    probePath2: vizIds.probePath2Id || null
                };
                console.debug('updateMiddleWizard: animInput', animInput);

                if (!window.__middleAnimator) {
                    // Use fixed, user-visible animation timings (don't use feed-rate numbers directly)
                    window.__middleAnimator = new window.PathAnimator({ probeMs: 1000, retractMs: 500, jogMs: 1500 });
                    console.debug('updateMiddleWizard: created __middleAnimator');
                }

                // play asynchronously (do not block UI) — stop any running animation first
                setTimeout(() => {
                    try {
                        console.debug('updateMiddleWizard: stopping previous animator (if any)');
                        window.__middleAnimator.stop();
                    } catch (e) { console.debug('updateMiddleWizard: stop() threw', e); }
                    console.debug('updateMiddleWizard: starting playSequence with animInput');
                    window.__middleAnimator.playSequence(animInput).then(() => {
                      console.debug('updateMiddleWizard: playSequence completed');
                    }).catch(err => {
                      console.debug('updateMiddleWizard: playSequence rejected', err);
                    });
                }, 60);
            } catch (err) {
                console.warn('MiddleViz autoplay failed', err);
            }
        }
    }

    updateEdgeWizard() {
        const params = {
            axis: el('p_axis')?.value || 'X',
            dir: el('p_dir')?.value || 'pos',
            wcs: el('p_wcs')?.value || 'G54',
            dist: el('p_dist')?.value || '15',
            retract: el('p_retract')?.value || '2',
            clearance: el('p_edge_clear')?.value || '2',
            findBoth: el('p_both')?.checked || false,
            syncA: el('p_sync_a')?.checked || false,
            slave: el('p_slave')?.value || '3',
            f_fast: el('p_feed_fast')?.value || '200',
            f_slow: el('p_feed_slow')?.value || '50',
            port: el('p_port')?.value || '3',
            level: el('p_level')?.value || '0',
            qStop: el('p_q')?.value || '1'
        };

        console.debug('updateEdgeWizard', params);
        const gcode = this.edgeWizard.generate(params);
        console.debug('edge generate => containsG31=', /G31/.test(gcode));
        el('wiz_edge_code').innerHTML = UIUtils.formatGCode(gcode);

        // Update edge status label
        const edgeStatus = el('edgeVizStatus');
        if (edgeStatus) edgeStatus.textContent = `Edge: ${params.axis}${params.dir === 'pos' ? '+' : '-'}${params.findBoth ? ' | Find Opposite' : ''}`;

        // Update visualization if function exists
        if (window.drawProbeViz) {
            window.drawProbeViz();
        }
    }

    insert() {
        let code = '';

        // Helper to check if a specific wizard panel is currently visible
        const isVisible = (id) => {
            const element = el(id);
            return element && element.style.display !== 'none';
        };

        // Determine which wizard is active and get its code
        if (isVisible('wiz_comm')) {
            code = el('wiz_comm_code')?.textContent;
        } else if (isVisible('wiz_wcs')) {
            code = el('wiz_wcs_code')?.textContent;
        } else if (isVisible('wiz_corner')) {
            code = el('wiz_corner_code')?.textContent;
        } else if (isVisible('wiz_middle')) {
            code = el('wiz_middle_code')?.textContent;
        } else if (isVisible('wiz_edge')) {
            code = el('wiz_edge_code')?.textContent;
        }

        if (code) {
            this.editorManager.insert(code);
        } else {
            console.warn('WizardManager: No visible wizard or empty code.');
        }
        
        this.close();
    }

    togglePreview() {
        const commPreview = el('comm_preview_block');
        const wcsPreview = el('wcs_preview_block');
        const probePreview = el('probe_preview_block');

        if (commPreview) commPreview.classList.toggle('hidden');
        if (wcsPreview) wcsPreview.classList.toggle('hidden');
        if (probePreview) probePreview.classList.toggle('hidden');
    }
}
